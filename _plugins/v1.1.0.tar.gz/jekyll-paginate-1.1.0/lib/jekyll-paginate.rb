require "jekyll-paginate/version"
require "jekyll-paginate/pager"
require "jekyll-paginate/pagination"

module Jekyll
  module Paginate
  end
end
