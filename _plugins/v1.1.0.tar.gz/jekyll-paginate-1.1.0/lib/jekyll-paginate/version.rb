module Jekyll
  module Paginate
    VERSION = "1.1.0"
  end
end
